import api from './api';
import { Bureau, BureauFormData, BureauxResponse } from '../types/bureau';

export const bureauxService = {
  getAll: async (search?: string): Promise<Bureau[]> => {
    const params = search ? { search } : {};
    const response = await api.get<BureauxResponse>('/bureaux', { params });
    return response.data.bureaux;
  },

  getById: async (id: string): Promise<Bureau> => {
    const response = await api.get(`/bureaux/${id}`);
    return response.data.bureau;
  },

  getByCode: async (code: string): Promise<Bureau> => {
    const response = await api.get(`/bureaux/code/${code}`);
    return response.data.bureau;
  },

  create: async (data: BureauFormData): Promise<Bureau> => {
    const response = await api.post('/bureaux', data);
    return response.data.bureau;
  },

  update: async (id: string, data: Partial<BureauFormData>): Promise<Bureau> => {
    const response = await api.put(`/bureaux/${id}`, data);
    return response.data.bureau;
  },

  delete: async (id: string): Promise<void> => {
    await api.delete(`/bureaux/${id}`);
  },
};
